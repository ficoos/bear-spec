#!/usr/bin/env sh

# XFAIL: *
# RUN: %{intercept} --verbose --output %t.sqlite3 -- %{false}

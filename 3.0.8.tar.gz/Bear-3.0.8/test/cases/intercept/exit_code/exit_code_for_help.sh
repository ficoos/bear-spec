#!/usr/bin/env sh

# RUN: %{intercept} --help
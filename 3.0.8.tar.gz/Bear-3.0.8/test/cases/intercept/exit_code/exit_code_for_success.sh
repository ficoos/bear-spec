#!/usr/bin/env sh

# RUN: %{intercept} --verbose --output %t.sqlite3 -- %{true}

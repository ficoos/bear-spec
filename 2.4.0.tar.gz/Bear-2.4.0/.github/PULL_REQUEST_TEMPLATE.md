### Fix or Enhancement?



- [ ] New tests added
- [ ] All tests passed

### Environment
- OS:
- Bear version:

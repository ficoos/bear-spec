If you attach log output, please consider to run Bear with `-vvvv` to have debug logs available.

### Expected Behavior


### Actual Behavior


### Environment

- OS name & version:
- Bear version:
- Any reference to the project that you running against:
- Any information about the compiler that this project is using:
